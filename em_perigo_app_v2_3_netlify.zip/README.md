# Em Perigo — Atlas Vivo v2.3

Acabamento editorial das 5 espécies-piloto, sem adicionar espécies.

Novidades:
- Características únicas passam a usar imagens locais dedicadas, uma por detalhe.
- Dieta passa a ter iconografia vetorial sem emojis, com símbolos coerentes com o alimento.
- Habitat, estado, localização, ameaças e conservação usam uma linguagem de ícones SVG consistente.
- Ajustes de textura, contraste, sombras e hierarquia tipográfica do infográfico.
- Mantidas as fotografias/habitats e mapas aprovados da v2.2.
- Catálogo continua com exatamente cinco espécies.
- Cache PWA atualizada.

Deploy: publicar diretamente no Netlify, sem build.
