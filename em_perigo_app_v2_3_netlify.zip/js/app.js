
const state={species:[],view:'home',lastView:'home',map:null,cluster:null,selected:null,detailMap:null};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const favs=()=>JSON.parse(localStorage.getItem('emPerigoFavs')||'[]');
const saveFavs=f=>localStorage.setItem('emPerigoFavs',JSON.stringify(f));
const isFav=id=>favs().includes(id);
const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const imgTag=(s,cls='')=>`<img class="${cls}" src="${s.image}" alt="${safe(s.name)}" onerror="this.onerror=null;this.src='assets/fallback.jpg'">`;
const svgIcon=(name,cls='')=>{
  const paths={
    population:`<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>`,
    status:`<path d="M12 3v18M5 12h14"/><path d="M7 7l10 10M17 7L7 17"/>`,
    location:`<path d="M12 21s6-5.2 6-11a6 6 0 1 0-12 0c0 5.8 6 11 6 11Z"/><circle cx="12" cy="10" r="2.2"/>`,
    forest:`<path d="M12 3 7 10h3l-4 6h4v5h4v-5h4l-4-6h3Z"/>`,
    mountain:`<path d="m3 19 6-10 4 6 2-3 6 7Z"/>`,
    climate:`<path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9"/><circle cx="12" cy="12" r="2.2"/>`,
    deer:`<path d="M7 15c0-3 2-5 5-5h3l2-3 2 1-1 3c1 1 2 2 2 4v4h-2v-3h-6l-1 3H9l1-4H7Z"/><path d="m16 7-1-3m3 4 2-3"/>`,
    boar:`<path d="M4 14c0-3 3-5 7-5h5l3 2v5l-3 2H8c-2 0-4-2-4-4Z"/><path d="M19 13h2M8 18v3m7-3v3"/>`,
    "small-mammal":`<ellipse cx="11" cy="14" rx="6" ry="4"/><circle cx="16" cy="11" r="2"/><path d="M5 14c-3 0-3 3-1 4"/>`,
    primate:`<circle cx="12" cy="7" r="3"/><path d="M8 11c2-2 6-2 8 0l2 5-3 2-1-4v7h-4v-7l-1 4-3-2Z"/>`,
    leaf:`<path d="M20 4C11 4 5 9 5 16c0 3 2 4 4 4 7 0 11-7 11-16Z"/><path d="M7 18c3-4 6-6 11-10"/>`,
    shoot:`<path d="M12 21V8"/><path d="M12 12c-4 0-6-2-6-5 4 0 6 2 6 5Zm0 3c4 0 6-2 6-5-4 0-6 2-6 5Z"/>`,
    fruit:`<circle cx="12" cy="14" r="6"/><path d="M12 8c0-3 2-4 4-4"/><path d="M13 6c2-2 4-1 5 0"/>`,
    branch:`<path d="M5 20 18 5M10 15 6 10m8 1 4 3M13 10 11 6"/>`,
    bamboo:`<path d="M9 21 11 3m4 18 2-18M10 8h6m-6 6h6"/><path d="M17 8c3 0 4-2 4-4-3 0-4 2-4 4ZM10 12c-3 0-4-2-4-4 3 0 4 2 4 4Z"/>`,
    stem:`<path d="M10 21 12 3m4 18 1-18M11 8h6m-7 6h6"/>`,
    nut:`<ellipse cx="12" cy="14" rx="6" ry="7"/><path d="M8 8c2-3 6-3 8 0M9 5h6"/>`,
    seed:`<path d="M12 4c5 4 6 10 0 16-6-6-5-12 0-16Z"/><path d="M12 6v12"/>`,
    "palm-fruit":`<circle cx="12" cy="14" r="5"/><path d="M12 9V4m0 1c-4 0-6 2-7 4m7-4c4 0 6 2 7 4"/>`,
    threat:`<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3h.01"/>`,
    habitat:`<path d="M4 20V9l8-5 8 5v11"/><path d="M9 20v-6h6v6"/>`,
    monitor:`<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 1v3m0 16v3M1 12h3m16 0h3"/>`,
    people:`<circle cx="9" cy="8" r="3"/><circle cx="16" cy="9" r="2.5"/><path d="M3 20c0-4 2-7 6-7s6 3 6 7m0-5c3 0 5 2 5 5"/>`,
    genetic:`<path d="M8 3c8 4 8 14 0 18m8-18C8 7 8 17 16 21M8 7h8M7 12h10M8 17h8"/>`
  };
  const body=paths[name]||paths.population;
  return `<svg class="svg-icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
};


async function boot(){
  state.species=await fetch('data/species.json').then(r=>r.json());
  $('#speciesCount').textContent=state.species.length;
  renderHome();renderList();renderFavorites();renderMapChips();bind();
  if('serviceWorker' in navigator) navigator.serviceWorker.register('service-worker.js').catch(()=>{});
}
function bind(){
  $$('[data-view]').forEach(b=>b.onclick=()=>show(b.dataset.view));
  $('#homeSearch').addEventListener('input',e=>{if(e.target.value.trim().length>1){show('list');$('#listSearch').value=e.target.value;renderList()}});
  $('#listSearch').addEventListener('input',renderList);$('#statusFilter').addEventListener('change',renderList);
  $('#detailBack').onclick=()=>show(state.lastView||'list');
  $('#mapLocate').onclick=()=>{if(state.map)state.map.setView([12,15],2)};
}
function show(name){
  if(name!=='detail'&&state.view!=='detail') state.lastView=state.view;
  state.view=name;
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${name}`));
  $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  window.scrollTo({top:0,behavior:'instant'});
  if(name==='map')setTimeout(initMap,60);
  if(name==='favorites')renderFavorites();
}
function card(s){const ci={...s,image:s.cardImage||s.image};return `<article class="species-card" data-id="${s.id}"><div class="card-photo">${imgTag(ci)}<span class="tag ${s.status}">${s.statusLabel}</span></div><div class="card-body"><b>${safe(s.name)}</b><i>${safe(s.scientific)}</i><small>${safe(s.place)}</small></div></article>`}
function renderHome(){
  $('#featuredGrid').innerHTML=state.species.map(card).join('');
  $('#featuredGrid').onclick=e=>{const c=e.target.closest('[data-id]');if(c)openSpecies(c.dataset.id,'home')};
}
function renderList(){
  const q=($('#listSearch')?.value||'').toLowerCase(),st=$('#statusFilter')?.value||'';
  const rows=state.species.filter(s=>(!st||s.status===st)&&(!q||[s.name,s.scientific,s.place,s.region].join(' ').toLowerCase().includes(q)));
  if($('#listCount'))$('#listCount').textContent=`${rows.length} espécies`;
  $('#speciesList').innerHTML=rows.map(s=>`<article class="list-row" data-id="${s.id}">${imgTag(s)}<div><b>${safe(s.name)}</b><i>${safe(s.scientific)}</i></div><span class="tag ${s.status}">${s.status}</span><small class="place">${safe(s.place)}</small><span>›</span></article>`).join('');
  $('#speciesList').onclick=e=>{const r=e.target.closest('[data-id]');if(r)openSpecies(r.dataset.id,'list')};
}
function renderFavorites(){
  const rows=state.species.filter(s=>isFav(s.id));$('#favoritesGrid').innerHTML=rows.length?rows.map(card).join(''):`<p style="color:#9bada5">Ainda não tem favoritos.</p>`;
  $('#favoritesGrid').onclick=e=>{const c=e.target.closest('[data-id]');if(c)openSpecies(c.dataset.id,'favorites')};
}
function toggleFav(id){
  let f=favs();f=f.includes(id)?f.filter(x=>x!==id):[...f,id];saveFavs(f);renderFavorites();
  const b=$('#detailFav');if(b){b.classList.toggle('on',isFav(id));b.textContent=isFav(id)?'♥':'♡'}
}

function renderMapChips(){
  const cats=['Todas',...new Set(state.species.map(s=>s.category))];
  $('#mapChips').innerHTML=cats.map((c,i)=>`<button class="chip ${i===0?'active':''}" data-cat="${c==='Todas'?'':c}">${c}</button>`).join('');
  $('#mapChips').onclick=e=>{const b=e.target.closest('[data-cat]');if(!b)return;$$('#mapChips .chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderMarkers(b.dataset.cat)};
}
function initMap(){
  if(!state.map){
    state.map=L.map('map',{zoomControl:false,attributionControl:true,minZoom:2,maxZoom:12,worldCopyJump:true}).setView([12,15],2);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:12,attribution:'© OpenStreetMap'}).addTo(state.map);
  }
  state.map.invalidateSize();renderMarkers('');
}
function clusterIcon(cluster){
  const children=cluster.getAllChildMarkers(),statuses=children.map(m=>m.options.speciesStatus);
  const cls=statuses.every(x=>x==='CR')?'critical':statuses.every(x=>x==='VU')?'':'mixed';
  return L.divIcon({html:`<div class="cluster-bubble ${cls}">${cluster.getChildCount()}</div>`,className:'',iconSize:[55,55]});
}
function renderMarkers(category=''){
  if(!state.map)return;
  if(state.cluster)state.map.removeLayer(state.cluster);
  state.cluster=L.markerClusterGroup({maxClusterRadius:105,disableClusteringAtZoom:6,showCoverageOnHover:false,spiderfyOnMaxZoom:true,zoomToBoundsOnClick:true,iconCreateFunction:clusterIcon});
  state.species.filter(s=>!category||s.category===category).forEach(s=>{
    const icon=L.divIcon({className:'',html:`<div class="initial-marker ${s.status}"><span>${s.initials}</span></div>`,iconSize:[42,48],iconAnchor:[21,44]});
    const m=L.marker([s.lat,s.lng],{icon,speciesStatus:s.status}).on('click',()=>selectOnMap(s));
    state.cluster.addLayer(m);
  });
  state.map.addLayer(state.cluster);
}
function selectOnMap(s){
  state.selected=s;
  const el=$('#mapBottomCard');
  const mi={...s,image:s.cardImage||s.image};el.innerHTML=`${imgTag(mi)}<div class="map-card-copy"><span class="tag ${s.status}">${s.statusLabel}</span><b>${safe(s.name)}</b><i>${safe(s.scientific)}</i><small>⌖ ${safe(s.rangeLabel||s.place)}</small></div><span class="arrow">›</span>`;
  el.classList.add('show');el.onclick=()=>openSpecies(s.id,'map');
}

function openSpecies(id,from='list'){
  const s=state.species.find(x=>x.id===id);if(!s)return;state.lastView=from;
  const traits=(s.traits||[]).slice(0,3),diet=(s.dietItems||[]).slice(0,4),hf=(s.habitatFacts||[]).slice(0,3);
  const cropStyle=t=>{
    const p=(t.crop||'50% 50%').split(' '),x=parseFloat(p[0])||50,y=parseFloat(p[1])||50;
    return `--tx:${-(x-12)}%;--ty:${-(y-12)}%`;
  };
  $('#detailContent').innerHTML=`<article class="infographic">
    <section class="info-section info-top">
      <header class="info-header"><div class="info-title"><span class="tag ${s.status}">${s.statusLabel}</span><h1>${safe(s.name)}</h1><i>${safe(s.scientific)}</i></div><button id="detailFav" class="fav-btn ${isFav(s.id)?'on':''}">${isFav(s.id)?'♥':'♡'}</button></header>
      <div class="animal-data">
        <div class="stats-column"><p class="intro">${safe(s.intro||s.fact)}</p>
          <div class="stat"><span class="ico">${svgIcon("population")}</span><div><strong>${safe(s.population)}</strong><b>POPULAÇÃO ESTIMADA</b><small>${safe(s.trend)}</small></div></div>
          <div class="stat"><span class="ico">${svgIcon("status")}</span><div><strong>${safe(s.status)}</strong><b>ESTADO DE CONSERVAÇÃO</b><small>${safe(s.statusLabel)}</small></div></div>
          <div class="stat"><span class="ico">${svgIcon("location")}</span><div><strong>${safe(s.region)}</strong><b>LOCALIZAÇÃO</b><small>${safe(s.place)}</small></div></div>
        </div>
        <div class="animal-visual" style="--animal-pos:${s.photoPosition||'50% 45%'}">${imgTag(s)}</div>
      </div>
      <div class="unique-wrap"><span class="brush">CARACTERÍSTICAS ÚNICAS</span><div class="unique-grid">
        ${traits.map(t=>`<div class="unique-item"><div class="crop"><img src="${t.detailImage||s.image}" alt="${safe(t.title)}" onerror="this.onerror=null;this.src='${s.image}'"></div><div><h4>${safe(t.title)}</h4><p>${safe(t.text)}</p></div></div>`).join('')}
      </div></div>
    </section>

    <section class="info-section info-middle">
      <div class="habitat-panel">
        <div class="habitat-image"><img src="${s.habitatImage||s.image}" alt="Habitat de ${safe(s.name)}" onerror="this.onerror=null;this.src='assets/fallback.jpg'"><div class="habitat-title"><span class="brush">HABITAT: ${safe(s.habitat)}</span></div><div class="habitat-icons">${hf.map((x,i)=>`<div><span>${svgIcon(['forest','mountain','climate'][i%3])}</span><b>${safe(x)}</b></div>`).join('')}</div>${s.habitatCredit?`<small class="habitat-credit">${safe(s.habitatCredit)}</small>`:''}</div>
        <div class="habitat-copy">${safe(s.intro)} ${safe(s.habitat)}</div>
      </div>
      <div class="middle-grid">
        <div class="where-card"><div class="heading"><span class="brush">ONDE VIVE?</span></div><div class="species-range-map" id="speciesRangeMap"></div><div class="range-note"><b>${safe(s.rangeLabel)}</b><br>Os pontos indicam as áreas de ocorrência/fortes da espécie nesta versão do atlas.</div></div>
        <div class="diet-card"><div class="heading"><span class="brush">DIETA</span></div><h3>${safe(s.diet)}</h3><div class="diet-icons">${diet.map((d,i)=>`<div><span>${svgIcon((s.dietIconKeys||[])[i]||'leaf')}</span><b>${safe(d)}</b></div>`).join('')}</div></div>
      </div>
    </section>

    <section class="info-section info-bottom">
      <div class="threats"><span class="brush red">AMEAÇAS À SOBREVIVÊNCIA</span><div class="threat-grid">${s.threats.map((x,i)=>`<div class="threat-item"><span class="ico">${svgIcon('threat')}</span><div><b>${safe(x)}</b><small>Pressão relevante para a sobrevivência da espécie.</small></div></div>`).join('')}</div></div>
      <div class="save"><span class="brush green">COMO PODEMOS AJUDAR?</span><div class="save-grid">${s.actions.map((x,i)=>`<div class="save-item"><span>${svgIcon(['habitat','monitor','people','genetic'][i%4])}</span><b>${safe(x)}</b><small>Medida de conservação prioritária.</small></div>`).join('')}</div></div>
      <div class="closing"><div class="message">Preservar ${safe(s.name)} é preservar o futuro do habitat que chama de lar.</div><div class="polaroid">${imgTag(s)}<small>${safe(s.name)}</small></div></div>
      ${s.credit?`<div class="info-source-note">${safe(s.credit)}</div>`:''}
    </section>
  </article>`;
  $('#detailFav').onclick=()=>toggleFav(s.id);
  show('detail');setTimeout(()=>renderDetailMap(s),100);
}
function renderDetailMap(s){
  if(state.detailMap){state.detailMap.remove();state.detailMap=null}
  const pts=s.rangePoints||[[s.lat,s.lng]];
  state.detailMap=L.map('speciesRangeMap',{zoomControl:false,attributionControl:false,scrollWheelZoom:false,dragging:true}).setView([s.lat,s.lng],s.detailZoom||6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:12}).addTo(state.detailMap);
  pts.forEach((p,i)=>L.circleMarker(p,{radius:i===0?8:6,weight:2,color:'#fff',fillColor:i===0?'#e4a02d':'#698a43',fillOpacity:1}).addTo(state.detailMap));
  if(pts.length>1) state.detailMap.fitBounds(L.latLngBounds(pts).pad(.55),{maxZoom:s.detailZoom||7});
  setTimeout(()=>state.detailMap.invalidateSize(),50);
}
boot();
